try:
    from wizzi_utils.pyplot.pyplot_tools import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.pyplot import test
