try:
    from wizzi_utils.tflite.test.test_tflite import *
except ModuleNotFoundError as e:
    pass
