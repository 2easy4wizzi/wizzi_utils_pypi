try:
    from wizzi_utils.misc.misc_tools import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.misc import test
