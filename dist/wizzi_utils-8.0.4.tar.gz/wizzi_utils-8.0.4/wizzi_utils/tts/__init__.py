try:
    from wizzi_utils.tts.tts import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.tts import test
