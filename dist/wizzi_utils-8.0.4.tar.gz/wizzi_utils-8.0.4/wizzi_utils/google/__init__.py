try:
    from wizzi_utils.google.google_tools import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.google import test
