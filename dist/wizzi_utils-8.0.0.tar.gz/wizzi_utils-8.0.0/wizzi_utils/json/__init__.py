try:
    from wizzi_utils.json.json_tools import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.json import test
