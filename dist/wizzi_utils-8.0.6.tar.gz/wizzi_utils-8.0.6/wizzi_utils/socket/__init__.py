try:
    from wizzi_utils.socket.socket_tools import *
except ModuleNotFoundError as e:
    pass

from wizzi_utils.socket import test
